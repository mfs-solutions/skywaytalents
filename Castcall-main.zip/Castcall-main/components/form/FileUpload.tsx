import React, { useState, useCallback } from 'react';
import { Card } from '../common/Card';

interface FileUploadProps {
  id: string;
  label: string;
  helperText: string;
  acceptedFiles: string;
  maxFiles: number;
  files: File[];
  onFilesChange: (files: File[]) => void;
  progress?: number;
  disabled?: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({ id, label, helperText, acceptedFiles, maxFiles, files, onFilesChange, progress, disabled = false }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [previews, setPreviews] = useState<string[]>([]);
  const [errors, setErrors] = useState<string[]>([]);

  React.useEffect(() => {
    const newPreviews: string[] = [];
    if (files.length === 0) {
      setPreviews([]);
      return;
    }

    files.forEach(file => {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onloadend = () => {
          newPreviews.push(reader.result as string);
          if (newPreviews.length === files.length) {
            setPreviews(newPreviews);
          }
        };
        reader.readAsDataURL(file);
      }
    });
  }, [files]);

  const handleFileChange = (newFiles: FileList | null) => {
    if (newFiles) {
      setErrors([]); // No more file size validation

      const currentFiles = files;
      const incomingFiles = Array.from(newFiles);
      
      const combined = [...currentFiles, ...incomingFiles];
      const limited = combined.slice(0, maxFiles); // Still respect maxFiles for single file uploads
      onFilesChange(limited);
    }
  };

  const onDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    if (disabled) return;
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    if (disabled) return;
    e.preventDefault();
    setIsDragging(false);
  };
  
  const onDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    if (disabled) return;
    e.preventDefault();
  };

  const onDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    if (disabled) return;
    e.preventDefault();
    setIsDragging(false);
    handleFileChange(e.dataTransfer.files);
  }, [files, disabled, maxFiles]);

  const removeFile = (index: number) => {
    const newFiles = files.filter((_, i) => i !== index);
    onFilesChange(newFiles);
  };

  return (
    <Card className="w-full">
      <label htmlFor={id} className="block text-lg font-bold text-text-primary mb-2">{label}</label>
      <div
        onDragEnter={onDragEnter}
        onDragLeave={onDragLeave}
        onDragOver={onDragOver}
        onDrop={onDrop}
        className={`relative border-2 border-dashed rounded-lg p-6 text-center transition-colors
          ${disabled ? 'bg-slate-100 cursor-not-allowed' : 'cursor-pointer'}
          ${isDragging ? 'border-primary bg-blue-50' : 'border-slate-300 hover:border-primary'}
        `}
        onClick={() => !disabled && document.getElementById(id)?.click()}
      >
        <input
          type="file"
          id={id}
          multiple
          accept={acceptedFiles}
          onChange={(e) => handleFileChange(e.target.files)}
          className="hidden"
          disabled={files.length >= maxFiles || disabled}
        />
        <div className="flex flex-col items-center">
          <svg className="w-12 h-12 text-slate-400 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path></svg>
          <p className="text-sm text-secondary">
            <span className="font-semibold text-primary">Click to upload</span> or drag and drop
          </p>
          <p className="text-xs text-slate-500 mt-1">{helperText}</p>
          {files.length >= maxFiles && <p className="text-xs text-red-500 mt-1">Maximum files reached</p>}
        </div>
      </div>
       {errors.length > 0 && (
        <div className="mt-2 text-sm text-red-600">
          {errors.map((error, i) => <p key={i}>- {error}</p>)}
        </div>
      )}
      {progress !== undefined && progress > 0 && (
        <div className="mt-4">
          <div className="w-full bg-slate-200 rounded-full h-2.5">
            <div className="bg-primary h-2.5 rounded-full transition-all duration-300" style={{ width: `${progress}%` }}></div>
          </div>
        </div>
      )}
      {files.length > 0 && (
        <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {files.map((file, index) => (
            <div key={index} className="relative group">
              {file.type.startsWith('image/') ? (
                <img src={previews[index]} alt={file.name} className="w-full h-24 object-cover rounded-md" />
              ) : (
                <div className="w-full h-24 bg-slate-100 rounded-md flex items-center justify-center p-2">
                  <p className="text-xs text-center break-all">{file.name}</p>
                </div>
              )}
              <button
                onClick={() => !disabled && removeFile(index)}
                className={`absolute top-1 right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity ${disabled ? 'hidden' : ''}`}
              >
                X
              </button>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
};