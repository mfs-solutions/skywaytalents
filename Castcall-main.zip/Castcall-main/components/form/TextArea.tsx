import React from 'react';

interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  error?: string;
}

export const TextArea: React.FC<TextAreaProps> = ({ label, id, error, ...props }) => {
  return (
    <div className="w-full">
      <label htmlFor={id} className="block text-sm font-medium text-text-primary mb-1">{label}</label>
      <textarea
        id={id}
        rows={4}
        className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 transition-colors bg-secondary text-white placeholder-slate-300 ${error ? 'border-red-500 focus:ring-red-400' : 'border-slate-500 focus:ring-primary'}`}
        {...props}
      />
      {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
    </div>
  );
};
