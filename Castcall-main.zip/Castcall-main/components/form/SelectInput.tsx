import React from 'react';

interface SelectInputProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  error?: string;
  children: React.ReactNode;
}

export const SelectInput: React.FC<SelectInputProps> = ({ label, id, error, children, ...props }) => {
  return (
    <div className="w-full">
      <label htmlFor={id} className="block text-sm font-medium text-text-primary mb-1">{label}</label>
      <select
        id={id}
        className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 transition-colors bg-secondary text-white ${error ? 'border-red-500 focus:ring-red-400' : 'border-slate-500 focus:ring-primary'}`}
        {...props}
      >
        {children}
      </select>
      {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
    </div>
  );
};
