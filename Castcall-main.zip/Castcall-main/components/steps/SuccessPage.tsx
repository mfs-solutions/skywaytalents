import React from 'react';
import { Card } from '../common/Card';
import { Button } from '../common/Button';

interface SuccessPageProps {
  restart: () => void;
  applicationId: string | null;
}

export const SuccessPage: React.FC<SuccessPageProps> = ({ restart, applicationId }) => {
  return (
    <Card className="text-center py-12 md:py-16">
      <div className="flex justify-center mb-4">
        <div className="bg-green-100 p-3 rounded-full">
          <svg className="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
        </div>
      </div>
      <h2 className="text-2xl md:text-3xl font-bold text-text-primary mb-2">Application Successfully Submitted!</h2>
      {applicationId && (
          <p className="text-secondary mb-4">Your Application ID is: <span className="font-bold text-text-primary bg-slate-200 px-2 py-1 rounded">{applicationId}</span></p>
      )}
      <p className="text-secondary mb-8 max-w-md mx-auto">
        Thank you for your application. Our team will review your portfolio and details carefully. If you are shortlisted, we will contact you via email for the next steps. All the best!
      </p>
      <Button onClick={restart}>
        Return Home
      </Button>
    </Card>
  );
};