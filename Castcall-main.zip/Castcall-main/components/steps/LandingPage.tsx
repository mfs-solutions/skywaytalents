
import React, { useState } from 'react';
import { Button } from '../common/Button';
import { Card } from '../common/Card';

interface LandingPageProps {
  nextStep: () => void;
}

const RoleCard: React.FC<{ title: string; details: { key: string; value: string }[] }> = ({ title, details }) => (
    <Card className="flex-1 min-w-[280px]">
        <h3 className="text-xl font-bold text-primary mb-3">{title}</h3>
        <ul className="space-y-2 text-sm text-secondary">
            {details.map(detail => (
                <li key={detail.key}>
                    <span className="font-semibold text-text-primary">{detail.key}:</span> {detail.value}
                </li>
            ))}
        </ul>
    </Card>
);


export const LandingPage: React.FC<LandingPageProps> = ({ nextStep }) => {
    const [agreed, setAgreed] = useState(false);
    
    return (
        <div className="space-y-8">
            <header className="text-center">
                <h1 className="text-3xl md:text-4xl font-bold text-text-primary">CASTING CALL: FEMALE ACTRESSES FOR A COLLEGE THRILLER</h1>
                <p className="text-md text-secondary mt-2">Production Title: [Project Name - To Be Announced]</p>
                <div className="mt-4 flex justify-center gap-2 flex-wrap">
                    <span className="bg-blue-100 text-primary text-xs font-semibold px-2.5 py-0.5 rounded-full">College-Based Thriller (Gangs, Love, Drugs)</span>
                    <span className="bg-slate-200 text-secondary text-xs font-semibold px-2.5 py-0.5 rounded-full">Shooting Locations: Bangalore & Chennai</span>
                </div>
            </header>

            <Card>
                <p className="text-center text-secondary leading-relaxed">
                    We are seeking 6 dedicated and talented female actresses for a hard-hitting short film that explores the dark underbelly of college life. The story tackles intense themes of gangs, love, and the impact of drugs on society.
                </p>
            </Card>

            <section>
                <h2 className="text-2xl font-bold text-center text-text-primary mb-6">Available Roles</h2>
                <div className="flex flex-wrap justify-center gap-6">
                    <RoleCard title="MAIN ROLE (1 Position)" details={[
                        { key: "Age", value: "18-27" },
                        { key: "Requirements", value: "Slim, fit, fair-skinned" },
                        { key: "Skills", value: "Clear acting and dancing skills mandatory" },
                        { key: "Note", value: "Newcomers welcome" }
                    ]}/>
                    <RoleCard title="SUPPORTING ROLE (3 Positions)" details={[
                        { key: "Age", value: "25-35" },
                        { key: "Requirements", value: "Better looks, fit body shape, fair skin" },
                        { key: "Skills", value: "Strong acting skills must" }
                    ]}/>
                    <RoleCard title="TEACHER ROLE (2 Positions)" details={[
                        { key: "Age", value: "30-40" },
                        { key: "Requirements", value: "Mature and sophisticated look" }
                    ]}/>
                </div>
            </section>
            
            <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-r-lg" role="alert">
                <p className="font-bold">⚠️ MANDATORY REQUIREMENT</p>
                <p>All selected candidates must be willing to relocate to Bangalore and Chennai for the shooting schedule.</p>
            </div>

            <div className="flex flex-col items-center space-y-4">
                <div className="flex items-center">
                    <input 
                        id="agreement" 
                        type="checkbox" 
                        checked={agreed}
                        onChange={(e) => setAgreed(e.target.checked)}
                        className="w-4 h-4 text-primary bg-gray-100 border-gray-300 rounded focus:ring-primary" 
                    />
                    <label htmlFor="agreement" className="ml-2 text-sm font-medium text-secondary">I have read, understood, and agree to all the details mentioned above.</label>
                </div>
                <Button onClick={nextStep} disabled={!agreed}>
                    APPLY NOW
                </Button>
            </div>
        </div>
    );
};
