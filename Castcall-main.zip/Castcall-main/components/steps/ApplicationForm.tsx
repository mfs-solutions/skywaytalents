
import React, { useState } from 'react';
import { FormData, Role, MaritalStatus } from '../../types';
import { Button } from '../common/Button';
import { Card } from '../common/Card';
import { ProgressIndicator } from '../common/ProgressIndicator';
import { TextInput } from '../form/TextInput';
import { TextArea } from '../form/TextArea';
import { SelectInput } from '../form/SelectInput';
import { ToggleGrid } from '../form/ToggleGrid';
import { Modal } from '../common/Modal';
import { analyzeImageForMeasurements } from '../../gemini';

interface ApplicationFormProps {
  nextStep: () => void;
  prevStep: () => void;
  formData: FormData;
  updateFormData: (data: Partial<FormData>) => void;
}

const costumeOptions = [
    { key: 'traditional', label: 'Traditional' }, { key: 'western', label: 'Western' }, { key: 'skinfit', label: 'Skinfit' }, { key: 'skirt', label: 'Skirt' }, { key: 'shorts', label: 'Shorts' }, { key: 'topless', label: 'Topless' }, { key: 'bikini', label: 'Bikini' }, { key: 'halfNudes', label: 'Half Nudes' },
];
const dressCodeOptions = [
    { key: 'ethnic', label: 'Ethnic Wear' }, { key: 'western', label: 'Western Wear' }, { key: 'swimSuit', label: 'Swim Suit' }, { key: 'bikini', label: 'Bikini' }, { key: 'lingerie', label: 'Lingerie' }, { key: 'shorts', label: 'Shorts' },
];
const sceneComfortOptions = [
    { key: 'emotional', label: 'Emotional' }, { key: 'dancing', label: 'Dancing' }, { key: 'kiss', label: 'Kiss' }, { key: 'smooch', label: 'Smooch' }, { key: 'loveMaking', label: 'Love Making' }, { key: 'bold', label: 'Bold Scene' },
];


export const ApplicationForm: React.FC<ApplicationFormProps> = ({ nextStep, prevStep, formData, updateFormData }) => {
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isAnalysisModalOpen, setIsAnalysisModalOpen] = useState(false);
    const [analysisImage, setAnalysisImage] = useState<File | null>(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [analysisError, setAnalysisError] = useState<string | null>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        updateFormData({ [e.target.name]: e.target.value });
    };

    const handleNestedChange = <T extends keyof FormData>(
      section: T, 
      field: keyof FormData[T], 
      value: string | number
    ) => {
      updateFormData({
        [section]: {
          ...(formData[section] as object),
          [field]: value,
        },
      });
    };

    const handleToggleChange = <T extends keyof FormData>(
      section: T,
      key: string,
      value: boolean
    ) => {
        handleNestedChange(section, key as keyof FormData[T], value as any);
    };

    const handleAnalyzeImage = async () => {
      if (!analysisImage) return;
      setIsAnalyzing(true);
      setAnalysisError(null);
      try {
        const newMeasurements = await analyzeImageForMeasurements(analysisImage);
        const combinedMeasurements = { ...formData.measurements };
        
        Object.keys(newMeasurements).forEach(key => {
            const typedKey = key as keyof FormData['measurements'];
            const value = newMeasurements[typedKey];
            if (value !== null && value !== undefined) {
                // @ts-ignore
                combinedMeasurements[typedKey] = value;
            }
        });

        updateFormData({ measurements: combinedMeasurements });
        setIsAnalysisModalOpen(false);
        setAnalysisImage(null);
      } catch (error) {
        console.error(error);
        setAnalysisError(error instanceof Error ? error.message : "An unknown error occurred during analysis.");
      } finally {
        setIsAnalyzing(false);
      }
    };

    const validate = () => {
        const newErrors: Record<string, string> = {};
        if (!formData.aim) newErrors.aim = "Please select a role.";
        if (!formData.fullName.trim()) newErrors.fullName = "Full name is required.";
        if (!formData.age) newErrors.age = "Age is required.";
        if (formData.age && (+formData.age < 18 || +formData.age > 40)) newErrors.age = "Please enter a valid age (18-40).";
        if (!formData.measurements.height) newErrors.height = "Required";
        if (!formData.measurements.weight) newErrors.weight = "Required";

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };
    
    const handleNext = () => {
        if (validate()) {
            nextStep();
        }
    };

  return (
    <div className="space-y-6">
      <ProgressIndicator currentStep={2} />
      <Card>
        <form className="space-y-8" noValidate>
          <section>
            <h3 className="text-lg font-bold text-text-primary mb-4">Application Details</h3>
            <SelectInput label="Aim" name="aim" value={formData.aim} onChange={handleChange} error={errors.aim}>
              <option value="">Select a Role</option>
              {Object.values(Role).map(role => <option key={role} value={role}>{role}</option>)}
            </SelectInput>
          </section>

          <section>
            <h3 className="text-lg font-bold text-text-primary mb-4">Personal Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <TextInput label="Full Name" name="fullName" value={formData.fullName} onChange={handleChange} error={errors.fullName} required/>
              <TextInput label="Age" name="age" type="number" value={formData.age} onChange={handleChange} error={errors.age} required/>
              <SelectInput label="Marital Status" name="maritalStatus" value={formData.maritalStatus} onChange={handleChange}>
                <option value="">Select Status</option>
                {Object.values(MaritalStatus).map(status => <option key={status} value={status}>{status}</option>)}
              </SelectInput>
              <div className="md:col-span-2">
                <TextArea label="Family Details" name="familyDetails" value={formData.familyDetails} onChange={handleChange} />
              </div>
            </div>
          </section>

          <ToggleGrid title="Costume Comfort" options={costumeOptions} values={formData.costumeComfort} onChange={(key, value) => handleToggleChange('costumeComfort', key, value)} />

          <section>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-text-primary">Body Measurements</h3>
                <Button type="button" variant="secondary" onClick={() => setIsAnalysisModalOpen(true)}>
                    ✨ Auto-fill
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                  <TextInput label="Height (cm)" type="number" value={formData.measurements.height} onChange={(e) => handleNestedChange('measurements', 'height', e.target.value)} error={errors.height} />
                  <TextInput label="Weight (kg)" type="number" value={formData.measurements.weight} onChange={(e) => handleNestedChange('measurements', 'weight', e.target.value)} error={errors.weight} />
                  <TextInput label="Skin Colour" value={formData.measurements.skinColour} onChange={(e) => handleNestedChange('measurements', 'skinColour', e.target.value)} />
                  <TextInput label="Bust (inches)" type="number" value={formData.measurements.bust} onChange={(e) => handleNestedChange('measurements', 'bust', e.target.value)} />
                  <TextInput label="Waist (inches)" type="number" value={formData.measurements.waist} onChange={(e) => handleNestedChange('measurements', 'waist', e.target.value)} />
                  <TextInput label="Hip (inches)" type="number" value={formData.measurements.hip} onChange={(e) => handleNestedChange('measurements', 'hip', e.target.value)} />
                  <TextInput label="Back Shape" value={formData.measurements.backShape} onChange={(e) => handleNestedChange('measurements', 'backShape', e.target.value)} />
                  <TextInput label="Thighs (inches)" type="number" value={formData.measurements.thighs} onChange={(e) => handleNestedChange('measurements', 'thighs', e.target.value)} />
                  <TextInput label="Eye Colour" value={formData.measurements.eyeColour} onChange={(e) => handleNestedChange('measurements', 'eyeColour', e.target.value)} />
                  <TextInput label="Hair Colour" value={formData.measurements.hairColour} onChange={(e) => handleNestedChange('measurements', 'hairColour', e.target.value)} />
              </div>
          </section>
          
          <ToggleGrid title="Dress Code Portfolio" options={dressCodeOptions} values={formData.dressCodePortfolio} onChange={(key, value) => handleToggleChange('dressCodePortfolio', key, value)} />
          <ToggleGrid title="Scene Comfort Level" options={sceneComfortOptions} values={formData.sceneComfort} onChange={(key, value) => handleToggleChange('sceneComfort', key, value)} />

          <section>
            <h3 className="text-lg font-bold text-text-primary mb-4">Additional Information</h3>
            <TextArea label="" name="additionalInfo" value={formData.additionalInfo} onChange={handleChange} />
          </section>

        </form>
      </Card>
      <div className="flex justify-between">
        <Button variant="secondary" onClick={prevStep}>BACK</Button>
        <Button onClick={handleNext}>NEXT</Button>
      </div>
      <Modal
        isOpen={isAnalysisModalOpen}
        onClose={() => !isAnalyzing && setIsAnalysisModalOpen(false)}
        title="Analyze Photo for Measurements"
      >
        <div className="space-y-4">
            <p className="text-sm text-secondary">
                Upload a full-body photo for AI-powered analysis. The image is used only for this analysis and will not be saved or submitted. Results may not be 100% accurate, so please review them.
            </p>
            <div>
                <label htmlFor="analysis-image-upload" className="block text-sm font-medium text-text-primary mb-1">Upload Image</label>
                <input
                    id="analysis-image-upload"
                    type="file"
                    accept="image/*"
                    onChange={(e) => setAnalysisImage(e.target.files ? e.target.files[0] : null)}
                    className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-primary hover:file:bg-blue-100"
                    disabled={isAnalyzing}
                />
            </div>
            {analysisImage && (
                <div className="text-center mt-4">
                    <img src={URL.createObjectURL(analysisImage)} alt="Preview" className="max-h-60 mx-auto rounded-lg shadow-md"/>
                </div>
            )}
            {analysisError && <p className="text-red-500 text-sm mt-2">{analysisError}</p>}
            <div className="flex justify-end gap-2 pt-4 border-t mt-4">
                 <Button type="button" variant="secondary" onClick={() => setIsAnalysisModalOpen(false)} disabled={isAnalyzing}>Cancel</Button>
                 <Button type="button" onClick={handleAnalyzeImage} disabled={!analysisImage || isAnalyzing}>
                    {isAnalyzing ? 'Analyzing...' : 'Analyze'}
                 </Button>
            </div>
        </div>
      </Modal>
    </div>
  );
};
