import React from 'react';
import { FormData, UploadProgress } from '../../types';
import { Button } from '../common/Button';
import { ProgressIndicator } from '../common/ProgressIndicator';
import { FileUpload } from '../form/FileUpload';

interface PortfolioUploadProps {
  nextStep: () => void;
  prevStep: () => void;
  formData: FormData;
  updateFormData: (data: Partial<FormData>) => void;
  isSubmitting: boolean;
  submissionError: string | null;
  uploadProgress: UploadProgress;
}

export const PortfolioUpload: React.FC<PortfolioUploadProps> = ({ nextStep, prevStep, formData, updateFormData, isSubmitting, submissionError, uploadProgress }) => {
  const handleFilesChange = (field: keyof FormData['portfolio'], files: File[]) => {
    updateFormData({
      portfolio: {
        ...formData.portfolio,
        [field]: files,
      },
    });
  };

  const checkMinimumFiles = () => {
    const { portfolio } = formData;
    if (portfolio.fullSizeImages.length < 3) return false;
    if (portfolio.introVideo.length < 1) return false;
    if (portfolio.casualImages.length < 2) return false;
    if (portfolio.westernImages.length < 2) return false;
    if (portfolio.shortsImages.length < 2) return false;
    if (portfolio.bikiniImages.length < 2) return false;
    return true;
  };

  const canSubmit = checkMinimumFiles();

  return (
    <div className="space-y-6 relative">
      <ProgressIndicator currentStep={3} />
       {isSubmitting && (
        <div className="absolute inset-0 bg-white bg-opacity-80 flex flex-col items-center justify-center z-10 rounded-lg p-4 text-center">
            <svg className="animate-spin h-10 w-10 text-primary mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <h3 className="text-lg font-semibold text-text-primary">Submitting your application...</h3>
            <p className="text-secondary">Please wait, this may take a few minutes depending on your connection.</p>
        </div>
      )}
      <div className={`space-y-6 ${isSubmitting ? 'opacity-50' : ''}`}>
          <FileUpload 
              id="fullSizeImages"
              label="Full Size Images (Minimum 3 required)"
              helperText="PNG, JPG accepted"
              acceptedFiles="image/*"
              maxFiles={99}
              files={formData.portfolio.fullSizeImages}
              onFilesChange={(files) => handleFilesChange('fullSizeImages', files)}
              progress={uploadProgress.fullSizeImages}
              disabled={isSubmitting}
          />
          <FileUpload 
              id="introVideo"
              label="Self Introduction Video (1 required)"
              helperText="MP4, MOV accepted"
              acceptedFiles="video/*"
              maxFiles={1}
              files={formData.portfolio.introVideo}
              onFilesChange={(files) => handleFilesChange('introVideo', files)}
              progress={uploadProgress.introVideo}
              disabled={isSubmitting}
          />
          <FileUpload 
              id="casualImages"
              label="Casual Outfit Images (Minimum 2 required)"
              helperText="PNG, JPG accepted"
              acceptedFiles="image/*"
              maxFiles={99}
              files={formData.portfolio.casualImages}
              onFilesChange={(files) => handleFilesChange('casualImages', files)}
              progress={uploadProgress.casualImages}
              disabled={isSubmitting}
          />
          <FileUpload 
              id="westernImages"
              label="Western Wear Images (Minimum 2 required)"
              helperText="PNG, JPG accepted"
              acceptedFiles="image/*"
              maxFiles={99}
              files={formData.portfolio.westernImages}
              onFilesChange={(files) => handleFilesChange('westernImages', files)}
              progress={uploadProgress.westernImages}
              disabled={isSubmitting}
          />
          <FileUpload 
              id="shortsImages"
              label="Shorts Images (Minimum 2 required)"
              helperText="PNG, JPG accepted"
              acceptedFiles="image/*"
              maxFiles={99}
              files={formData.portfolio.shortsImages}
              onFilesChange={(files) => handleFilesChange('shortsImages', files)}
              progress={uploadProgress.shortsImages}
              disabled={isSubmitting}
          />
           <FileUpload 
              id="bikiniImages"
              label="Bikini/Half Images (Minimum 2 required)"
              helperText="PNG, JPG accepted"
              acceptedFiles="image/*"
              maxFiles={99}
              files={formData.portfolio.bikiniImages}
              onFilesChange={(files) => handleFilesChange('bikiniImages', files)}
              progress={uploadProgress.bikiniImages}
              disabled={isSubmitting}
          />
      </div>
       {submissionError && (
          <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-r-lg mt-4" role="alert">
              <p className="font-bold">Submission Failed</p>
              <p>{submissionError}</p>
          </div>
      )}
      {!canSubmit && !isSubmitting && (
        <p className="text-center text-red-500 text-sm">
          Please upload the minimum number of files for each category to continue.
        </p>
      )}
      <div className="flex justify-between pt-4">
        <Button variant="secondary" onClick={prevStep} disabled={isSubmitting}>BACK</Button>
        <Button onClick={nextStep} disabled={isSubmitting || !canSubmit}>
          {isSubmitting ? 'SUBMITTING...' : 'FINISH'}
        </Button>
      </div>
    </div>
  );
};