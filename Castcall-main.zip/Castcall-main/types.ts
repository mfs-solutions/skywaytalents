export enum Role {
  MAIN = 'Main Role',
  SUPPORTING = 'Supporting Actress',
  TEACHER = 'Teacher Role',
}

export enum MaritalStatus {
  SINGLE = 'Single',
  MARRIED = 'Married',
  DIVORCED = 'Divorced',
}

export interface FormData {
  aim: Role | '';
  fullName: string;
  familyDetails: string;
  maritalStatus: MaritalStatus | '';
  age: number | '';
  
  costumeComfort: {
    traditional: boolean;
    western: boolean;
    skinfit: boolean;
    skirt: boolean;
    shorts: boolean;
    topless: boolean;
    bikini: boolean;
    halfNudes: boolean;
  };
  
  measurements: {
    height: number | '';
    weight: number | '';
    skinColour: string;
    bust: number | '';
    waist: number | '';
    hip: number | '';
    backShape: string;
    thighs: number | '';
    eyeColour: string;
    hairColour: string;
  };

  dressCodePortfolio: {
    ethnic: boolean;
    western: boolean;
    swimSuit: boolean;
    bikini: boolean;
    lingerie: boolean;
    shorts: boolean;
  };

  sceneComfort: {
    emotional: boolean;
    dancing: boolean;
    kiss: boolean;
    smooch: boolean;
    loveMaking: boolean;
    bold: boolean;
  };
  
  additionalInfo: string;

  portfolio: {
    fullSizeImages: File[];
    introVideo: File[];
    casualImages: File[];
    westernImages: File[];
    shortsImages: File[];
    bikiniImages: File[];
  }
}

export type UploadProgress = {
  [key in keyof FormData['portfolio']]?: number;
};

export const initialFormData: FormData = {
  aim: '',
  fullName: '',
  familyDetails: '',
  maritalStatus: '',
  age: '',
  costumeComfort: {
    traditional: false,
    western: false,
    skinfit: false,
    skirt: false,
    shorts: false,
    topless: false,
    bikini: false,
    halfNudes: false,
  },
  measurements: {
    height: '',
    weight: '',
    skinColour: '',
    bust: '',
    waist: '',
    hip: '',
    backShape: '',
    thighs: '',
    eyeColour: '',
    hairColour: '',
  },
  dressCodePortfolio: {
    ethnic: false,
    western: false,
    swimSuit: false,
    bikini: false,
    lingerie: false,
    shorts: false,
  },
  sceneComfort: {
    emotional: false,
    dancing: false,
    kiss: false,
    smooch: false,
    loveMaking: false,
    bold: false,
  },
  additionalInfo: '',
  portfolio: {
    fullSizeImages: [],
    introVideo: [],
    casualImages: [],
    westernImages: [],
    shortsImages: [],
    bikiniImages: [],
  }
};